package com.code.with.bisky.dto.chatgpt;

import lombok.Data;

@Data
public class ChatGptMessage {

    private String role;
    private String content;
}
