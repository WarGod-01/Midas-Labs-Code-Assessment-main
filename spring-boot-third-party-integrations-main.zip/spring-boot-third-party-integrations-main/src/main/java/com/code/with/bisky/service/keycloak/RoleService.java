package com.code.with.bisky.service.keycloak;

public interface RoleService {

    void assignRole(String userId,String roleName);
}
