package com.code.with.bisky.dto;

public record SubscriptionCancelRecord(String status) {
}
