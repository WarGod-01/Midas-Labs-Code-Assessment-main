package com.code.with.bisky;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntegrationWithBiskyApplicationTests {

	@Test
	void contextLoads() {
	}

}
